package co.edu.sena.testsring.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpa2Application.class, args);
	}

}
