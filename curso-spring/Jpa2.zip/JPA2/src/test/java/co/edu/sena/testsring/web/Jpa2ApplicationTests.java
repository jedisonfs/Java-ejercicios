package co.edu.sena.testsring.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
